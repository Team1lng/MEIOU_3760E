/home/xiaole/share/work/MeteC/ak_37e_sdk/os/driver_src/gsl1680/ts_gsl.ko
/home/xiaole/share/work/MeteC/ak_37e_sdk/os/driver_src/gsl1680/ts_gslX680.o /home/xiaole/share/work/MeteC/ak_37e_sdk/os/driver_src/gsl1680/gsl_point_id.o
