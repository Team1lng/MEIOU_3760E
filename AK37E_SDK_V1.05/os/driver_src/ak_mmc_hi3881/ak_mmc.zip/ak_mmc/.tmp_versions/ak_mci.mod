/home/share/two_wire_project/MEIOU/SDK/AK37E_SDK_1.05/os/driver_src/ak_mmc_hi3881/ak_mmc/ak_mci.ko
/home/share/two_wire_project/MEIOU/SDK/AK37E_SDK_1.05/os/driver_src/ak_mmc_hi3881/ak_mmc/ak_mci.o
