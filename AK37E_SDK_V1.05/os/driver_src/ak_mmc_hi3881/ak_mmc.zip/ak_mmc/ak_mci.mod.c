#include <linux/module.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

MODULE_INFO(vermagic, VERMAGIC_STRING);

__visible struct module __this_module
__attribute__((section(".gnu.linkonce.this_module"))) = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=mmc_core";

MODULE_ALIAS("of:N*T*Canyka,ak37d-mmc0*");
MODULE_ALIAS("of:N*T*Canyka,ak37d-mmc1*");
MODULE_ALIAS("of:N*T*Canyka,ak37d-mmc2*");
MODULE_ALIAS("of:N*T*Canyka,ak39ev330-mmc0*");
MODULE_ALIAS("of:N*T*Canyka,ak39ev330-mmc1*");
MODULE_ALIAS("of:N*T*Canyka,ak37e-mmc0*");
MODULE_ALIAS("of:N*T*Canyka,ak37e-mmc1*");
MODULE_ALIAS("of:N*T*Canyka,ak37e-mmc2*");

MODULE_INFO(srcversion, "DECE395472433120422C459");
