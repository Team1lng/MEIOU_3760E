/home/michael/share/AK37E_SDK_V1.05/os/driver_src/ak_eth/ak_eth.ko
/home/michael/share/AK37E_SDK_V1.05/os/driver_src/ak_eth/ak_eth.o
